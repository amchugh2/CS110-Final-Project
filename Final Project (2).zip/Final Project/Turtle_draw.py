import turtle
import ACos
import ASin
import ATan
import Cosine
import Exponential
import Ln
import Log
import Sine
import Tan

import GUI

POS_X_AXIS = 180
NEG_X_AXIS = -180
POS_Y_AXIS = 1.5
NEG_Y_AXIS = -1.5

# Acos/Asin/Atan axis
POS_X_AXIS2 = -2
NEG_X_AXIS2 = 2
POS_Y_AXIS2 = (math.pi + .5)
NEG_Y_AXIS2 = 0

# Ln/Log axis
POS_X_AXIS3 = 5
NEG_X_AXIS3 = -5
POS_Y_AXIS3 = 4
NEG_Y_AXIS3 = -3

# Exponential axis
POS_X_AXIS4 = 10
NEG_X_AXIS4 = -10
POS_Y_AXIS = 10
NEG_Y_AXIS = 0

class Turtle_draw:
  def create_background(self, background_input):
    wn = turtle.Screen()
    if self.__background_input == "yellow":
      wn.bgcolor("yellow")
    elif self.__background_input == "white":
      wn.bgcolor("white")
    elif self.__background_input == "light blue":
      wn.bgcolor("light blue")
    elif self.__background_input == "light green":
      wn.bgcolor("light green")
    else: # CALL ERROR - FIX

  def create_turtle(self, color_input):
    rose = turtle.Turtle()
    if self.__color_input == "black":
    rose.color("black")
    elif self.__color_input == "purple":
      rose.color("purple")
    elif self.__color_input == "red":
      rose.color("red")
    elif self.__color_input == "orange":
      rose.color("orange")
    else: # CALL ERROR - FIX
                 

  def create_axis1(self, type_graph):
    vlad = turtle.Turtle()
    # Set world coordinates
    wn.setworldcoordinates(NEG_X_AXIS, NEG_Y_AXIS, POS_X_AXIS, POS_Y_AXIS)

    # Create axis
    vlad.forward(180)
    vlad.backward(360)
    vlad.forward(180)
    vlad.left(90)
    vlad.forward(1.5)
    vlad.backward(3)

    # Label axis
    vlad.penup()
    vlad.goto(2,1.4)
    vlad.pendown()
    vlad.write("Y-axis")

    vlad.penup()
    vlad.goto(365,.05)
    vlad.pendown()
    vlad.write("X-axis")

    vlad.penup()
    vlad.goto(0,0)
    vlad.pendown()

  def create_axis2(self, type_graph):
      # Set world coordinates
      wn.setworldcoordinates(NEG_X_AXIS2, NEG_Y_AXIS2, POS_X_AXIS2, POS_Y_AXIS2)
      
      # Create axis
      vlad.forward(180)
      vlad.backward(360)
      vlad.forward(180)
      vlad.left(90)
      vlad.forward(1.5)

      # Label axis
      vlad.penup()
      vlad.goto(2,1.4)
      vlad.pendown()
      vlad.write("Y-axis")

      vlad.penup()
      vlad.goto(365,.05)
      vlad.pendown()
      vlad.write("X-axis")

      vlad.penup()
      vlad.goto(0,0)
      vlad.pendown()


    def create_axis3(self, type_graph)):

      # Set world coordinates
      wn.setworldcoordinates(NEG_X_AXIS3, NEG_Y_AXIS3, POS_X_AXIS3, POS_Y_AXIS3)

      # Create axis
      vlad.forward(180)
      vlad.backward(360)
      vlad.left(90)
      vlad.forward(1.5)

      # label axis
      vlad.penup()
      vlad.goto(2,1.4)
      vlad.pendown()
      vlad.write("Y-axis")

      vlad.penup()
      vlad.goto(365,.05)
      vlad.pendown()
      vlad.write("X-axis")

      vlad.penup()
      vlad.goto(0,0)
      vlad.pendown()

  def create_axis4(self, type_graph):
      # Set world coordinates
      wn.setworldcoordinates(NEG_X_AXIS4, NEG_Y_AXIS4, POS_X_AXIS4, POS_Y_AXIS4)

      # Create axis
      vlad.forward(180)
      vlad.backward(360)
      vlad.left(90)
      vlad.forward(1.5)

      # label axis
      vlad.penup()
      vlad.goto(2,1.4)
      vlad.pendown()
      vlad.write("Y-axis")

      vlad.penup()
      vlad.goto(365,.05)
      vlad.pendown()
      vlad.write("X-axis")

      vlad.penup()
      vlad.goto(0,0)
      vlad.pendown()
  
   def draw_graph(self, points):
     for x,y in points:
       vlad.goto(x,y)
        
    
    
    

    
  


    
    

    
  
