import math

class Sine:
  def __init__(self):
    self.__angle = 0
    self.__points = {}
    self.__x_list = []
    self.__y_list = []

  def sine_graph(self,angle):
    for angle in range(0, 361):
      x = angle
      y = math.sin(math.radians(angle))
      self.__x_list.append(x)
      self.__y_list.append(y)
    keys = x_list
    values = y_list
    self.__points = dict(zip(keys, values))

  def get_x_list(self):
    return self.__x_list

  def get_y_list(self):
    return self.__y_list
