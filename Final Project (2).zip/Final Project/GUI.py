import ACos
import ASin
import ATan
import Cosine
import Exponential
import Ln
import Log
import Sine
import Tan

import tkinter as tk
from tkinter import ttk
import matplotlib
matplotlib.use("TkAgg")

from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg, NavigationToolbar2Tk)

from matplotlib.figure import Figure

MENU_FONT = ("Comic Sans", 20)

class Start(tk.Tk):

  def __init__(self, *args, **kwargs):
    tk.Tk.__init__(self, *args, **kwargs)

    tk.Tk.wm_title(self, "Graph Generator")
    container = tk.Frame(self)

    container.pack(side = "top", fill = "both", expand = True)

    container.grid_rowconfigure(0, weight = 1)
    container.grid_columnconfigure(0, weight = 1)

    self.frames = {}
    frame = Menu(container, self)
    self.frames[Menu] = frame
    
    # sticky: alignment and stretch
    frame.grid(row = 0, column = 0, sticky = "nsew")
    
    
    frame = Menu(container, self)

    for F in (Menu, ACos, ASin, ATan, Cosine, Exponential, Ln, Log, Sine, Tan):
      frame = F(container, self)
      self.frames[F] = frame
      frame.grid(row = 0, column = 0)

    # show_frame is built into tkinter    

    # controller
  def show_frame(self, cont):
    frame = self.frames[cont]
    # raise to front
    frame.tkraise()

class Menu(tk.Frame):

  def __init__(self, parent, controller):
    self.controller = controller
    tk.Frame.__init__(self, parent)
    label = tk.Label(self, text = "Choose your Graph!", font = MENU_FONT)
    label.pack(pady = 10, padx = 10)

    # How do we call show_frame
    
    button1 = ttk.Button(self, text = "ACos", command = lambda: controller.show_frame(acos.ACos))
    button1.pack()
    
    button2 = ttk.Button(self, text = "ASin", command = lambda:show_frame(ASin))
    button2.pack()
    
    button3 = ttk.Button(self, text = "ATan", command = lambda:controller.show_frame(ATan))
    button3.pack()
    
    button4 = ttk.Button(self, text = "Cosine", command = lambda:controller.show_frame(Cosine))
    button4.pack()
    
    button5 = ttk.Button(self, text = "Exponential", command = lambda:controller.show_frame(Exponential))
    button5.pack()
    
    button6 = ttk.Button(self, text = "Ln", command = lambda:controller.show_frame(Ln))
    button6.pack()
    
    button7 = ttk.Button(self, text = "Log", command = lambda:controller.show_frame(Log))
    button7.pack()
    
    button8 = ttk.Button(self, text = "Sine", command = lambda:controller.show_frame(Sine))
    button8.pack()
    
    button9 = ttk.Button(self, text = "Tan", command = lambda:controller.show_frame(Tan))
    button9.pack() 

class ACos_gui(tk.Frame):
  def __init__(self, parent, controller):
    tk.Frame.__init__(self, parent)
    label = tk.Label(self, text = "ACos", font = MENU_FONT)
    label.pack(pady= 10, padx = 10)

    button_one = ttk.Button(self, text = "Go back to main menu", command = lambda: controller.show_frame(Menu))
    button_one.pack()

    f = Figure(figsize = (5,5), dpi = 100)
    graph = f.add_subplot(111)

    # Question: The way we are calling the dictionary
    acos_list = ACos()
    acos_list.acos_graph()
    
    graph.plot([acos_list.get_x_list()], [acos_list.get_y_list()])

    canvas = FigureCanvasTkAgg(f, self)
    canvas.draw()
    canvas.get_tk_widget().pack(side = tk.TOP, fill = tk.BOTH, expand = True)

    toolbar = NavigationToolbar2Tk(canvas, self)
    toolbar.update()
    canvas._tkcanvas.pack(side = tk.TOP, fill = tk.BOTH, expand = True)

app = Start()
app.mainloop()

'''
class graphGUI:
  
  def __init__(self):
    self.__window = Tk()
    self.__background_input = ''
    self.__color_input = ''
    self.__font = ''


    self.__top = Frame(self.__window)
    self.__mid1 = Frame(self.__window)
    self.__mid2 = Frame(self.__window)
    self.__mid3 = Frame(self.__window)
    self.__bottom = Frame(self.__window)

    # Create title
    self.__title = Label(self.__top, text = 'Pick A Graph')
    self.__title.config(font = ("Comic Sans", 30))

    # Create background color entry box
    # Subtitle
    self.__title2 = Label(self.__mid1, text = 'Pick a Background Color: \n' +\
                          'Choose either white, yellow, light green, or light blue')
    self.__title2.config(font = ("Comic Sans", 20))

    # Create entry box for background color
    self.__background_input = Entry(self.__mid1, n = 10)
    self.__background_input.bind("<Return>", self.__create_background)

    # Create label for color of turtle
    self.__title3 = Label(self__mid2, text = "Pick a Turtle Color: \n" +\
                          'Choose either purple, red, black, or orange')
    self.__title3.config(font = ("Comic Sans", 20))

    # Create entry box for color of turtle
    self.__title3 = Entry(self.__mid2, n = 10)
    self.__color_input.bind("<Return>", self.__color_input)
    
                         
    # Create function buttons
    # Subtitle
    self.__title4 = Label(self.__mid3, text = 'Choose a function')
    self.__title4.config(font = ("Comic Sans", 20))

    # Buttons
    self.__sine = Button(self.__mid3, text = 'Sine', command = self.create_axis1, self.sine_graph)
    self.__sine.config(font = ("Comic Sans", 12))

    
    self.__cosine = Button(self.__mid3, text = 'Cosine',
                           command = self.create_axis1, self.cosine_graph)
    self.__cosine.config(font = ("Comic Sans", 12))

                         
    self.__tan = Button(self.__mid3, text = 'Tangent',
                           command = self.create_axis1, self.tangent_graph)
    self.__tan.config(font = ("Comic Sans", 12))


    self.__a_sine = Button(self.__mid3, text = 'ASine',
                           command = self.create_axis2, self.asin_graph)
    self.__a_sine.config(font = ("Comic Sans", 12))


    self.__a_cosine = Button(self.__mid3, text = 'ACosine',
                           command = self.create_axis2, self.acos_graph)
    self.__a_cosine.config(font = ("Comic Sans", 12))


    self.__a_tan = Button(self.__mid3, text = 'ATangent',
                           command = self.create_axis2, self.atan_graph)
    self.__a_tan.config(font = ("Comic Sans", 12))


    self.__exp = Button(self.__mid3, text = 'Exponential',
                           command = self.create_axis4, self.exponential_graph)
    self.__exp.config(font = ("Comic Sans", 12))


    self.__ln = Button(self.__mid3, text = 'Ln',
                           command = self.create_axis3, self.ln_graph)
    self.__ln.config(font = ("Comic Sans", 12))


    self.__log = Button(self.__mid3, text = 'Log',
                           command = self.create_axis3, self.log_graph)
    self.log.config(font = ("Comic Sans", 12))
'''
